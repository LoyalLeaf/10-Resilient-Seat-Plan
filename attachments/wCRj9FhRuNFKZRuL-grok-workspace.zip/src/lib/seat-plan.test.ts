import assert from "node:assert/strict";
import test from "node:test";
import { arrange, bandFor, isChahna, type Student } from "./seat-plan.ts";

function student(name: string, points: number, eyesight = false): Student {
  const [lastName, given = ""] = name.split(",").map((part) => part.trim());
  return {
    name,
    lastName,
    givenName: given,
    points,
    sheetPoints: points,
    eyesight,
    key: name.toLowerCase(),
    hasOverride: false,
  };
}

test("Chahna is fixed at the front-left eyesight seat", () => {
  const plan = arrange([
    student("Yap, Chahna Mishael F.", 40, true),
    student("Berdin, Mathew S.", 1, true),
    student("Gumba, Malaika Ysabella C.", 3, true),
    student("Andrade, Ysabella Faye B.", 2),
  ]);
  const frontLeft = plan.desks.find((d) => d.rowFromFront === 0 && d.col === 0);
  assert.equal(frontLeft?.student && isChahna(frontLeft.student.name), true);
  const second = plan.desks.find((d) => d.rowFromFront === 0 && d.col === 1);
  assert.equal(second?.student?.lastName, "Berdin");
});

test("bands step at 10, 15, 20, 25, 30, 35, 40, 45, and 50", () => {
  assert.equal(bandFor(9), "rose");
  assert.equal(bandFor(10), "sand");
  assert.equal(bandFor(15), "mint");
  assert.equal(bandFor(25), "deep");
  assert.equal(bandFor(49), "indigo");
  assert.equal(bandFor(50), "gold");
});
