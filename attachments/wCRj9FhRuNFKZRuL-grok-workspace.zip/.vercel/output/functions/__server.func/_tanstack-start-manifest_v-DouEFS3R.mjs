//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DouEFS3R.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DIy6x-WN.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DIy6x-WN.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DVmxi-YM.js"]
	}
} });
//#endregion
export { tsrStartManifest };
