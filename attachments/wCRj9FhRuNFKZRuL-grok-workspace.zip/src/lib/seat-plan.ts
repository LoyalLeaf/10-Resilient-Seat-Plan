export type Student = {
  name: string;
  lastName: string;
  givenName: string;
  points: number;
  sheetPoints: number;
  eyesight: boolean;
  key: string;
  hasOverride: boolean;
};

export type Desk = {
  rowFromFront: number;
  col: number;
  role: "eyesight" | "regular";
  student: Student | null;
};

export type Plan = {
  desks: Desk[];
  unseated: Student[];
  studentCount: number;
};

type RowSpec = { cols: number[]; eyesight: number[] };

const EYESIGHT: Array<[string, string]> = [
  ["berdin", "mathew"],
  ["soriano", "jaye"],
  ["gumba", "malaika"],
  ["llames", "cianna"],
  ["de luna", "viktoria"],
  ["yap", "chahna"],
];

const ROWS: RowSpec[] = [
  { cols: [0, 1, 2, 3, 4, 5, 6, 7], eyesight: [0, 1, 2, 3, 4, 5] },
  { cols: [0, 1, 2, 3, 4, 5, 6, 7], eyesight: [] },
  { cols: [0, 1, 2, 3, 4, 5, 6, 7], eyesight: [] },
  { cols: [0, 1, 2, 3, 4, 5, 6, 7], eyesight: [] },
  { cols: [2, 3, 4, 5, 6], eyesight: [] },
];

/** Last 4 digits of each LRN. Key is a normalized "Last, Given" name. */
export const LRN_LAST4: Record<string, string> = {
  "arickx christoff r": "0003",
  "berdin mathew s": "0062",
  "datoon joshua caleb d": "0009",
  "olivan rein christian s": "0027",
  "ortile jun christian o": "0012",
  "patetico jesutivo noah": "9147",
  "prellegera john stephen p": "0054",
  "tominio carlo v": "0039",
  "andrade ysabella faye b": "0012",
  "babasa ghislaine br": "0022",
  "barameda summer vsn": "0039",
  "biag nigel shane c": "0072",
  "codia bielle jonahs a": "0191",
  "colecha kim n": "0079",
  "dacillo luvly jhamella c": "0010",
  "dacuya althea joy f": "0037",
  "de la fuente samiel yara r": "0138",
  "de luna viktoria r": "0009",
  "gumba malaika ysabella c": "0155",
  "lista matilda beatriz d": "0026",
  "llames cianna margarette t": "0039",
  "lumawon xyriel": "0108",
  "mar janna charlie o": "0025",
  "mengorio jelien purz": "0033",
  "moises jinky faye a": "0130",
  "morta amaia b": "0043",
  "opiana chriatia fatima m": "0007",
  "quiapon princess corrine y": "0015",
  "ramos jaira nicole s": "0045",
  "robrigado xiarah nicolette o": "0250",
  "rojero samara kate d": "0052",
  "saclag precious jade r": "0054",
  "satuito jaira airies c": "0047",
  "soriano jaye anne nazareth r": "0012",
  "teodoro ella jezrell e": "0029",
  "viray dennise keith y": "0157",
  "yap chahna mishael f": "0141",
};

export const SHEET_ID = "1Tok7fSsvIQWPN0cSUatx0NEQAPfbxbOR1clv8S1q6l8";
export const SHEET_EDIT_URL =
  "https://docs.google.com/spreadsheets/d/" + SHEET_ID + "/edit?gid=0#gid=0";
export const PASS_HASH =
  "eafa8d7ce4f9a2fd94e491b48c7f83ad180466680cd0d44d016b9192ff4a5143";

export const BANDS = [
  { id: "rose", label: "Under 10" },
  { id: "sand", label: "10+" },
  { id: "mint", label: "15+" },
  { id: "ice", label: "20+" },
  { id: "deep", label: "25+" },
  { id: "lilac", label: "30+" },
  { id: "amber", label: "35+" },
  { id: "teal", label: "40+" },
  { id: "indigo", label: "45+" },
  { id: "gold", label: "50" },
] as const;

export function norm(value: string): string {
  return String(value || "")
    .toLowerCase()
    .replace(/\./g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function lastNameOf(full: string): string {
  const i = full.indexOf(",");
  return (i === -1 ? full : full.slice(0, i)).trim();
}

export function givenNameOf(full: string): string {
  const i = full.indexOf(",");
  return (i === -1 ? "" : full.slice(i + 1)).trim();
}

function sortLastName(last: string): string {
  const particles = new Set([
    "de",
    "del",
    "dela",
    "la",
    "los",
    "las",
    "san",
    "santa",
    "sta",
    "sto",
  ]);
  const parts = last.split(/\s+/).filter(Boolean);
  let index = 0;
  while (
    index < parts.length - 1 &&
    particles.has(parts[index].toLowerCase().replace(/\./g, ""))
  ) {
    index += 1;
  }
  return index > 0 ? parts.slice(index).join(" ") : last;
}

export function isKnownEyesight(name: string): boolean {
  const last = norm(lastNameOf(name));
  const given = norm(givenNameOf(name));
  return EYESIGHT.some(([l, g]) => last === l && given.startsWith(g));
}

export function isChahna(name: string): boolean {
  return (
    norm(name) === "yap chahna mishael f" ||
    (norm(lastNameOf(name)) === "yap" && norm(givenNameOf(name)).startsWith("chahna"))
  );
}

export function bandFor(points: number): string {
  if (points < 10) return "rose";
  if (points < 15) return "sand";
  if (points < 20) return "mint";
  if (points < 25) return "ice";
  if (points < 30) return "deep";
  if (points < 35) return "lilac";
  if (points < 40) return "amber";
  if (points < 45) return "teal";
  if (points < 50) return "indigo";
  return "gold";
}

export function sortByRecitation(students: Student[]): Student[] {
  return students.slice().sort(compareStudents);
}

const CLASS_NAMES = [
  "Arickx, Christoff R.",
  "Berdin, Mathew S.",
  "Datoon, Joshua Caleb D.",
  "Olivan, Rein Christian S.",
  "Ortile, Jun Christian O.",
  "Patetico, Jesutivo Noah",
  "Prellegera, John Stephen P.",
  "Tominio, Carlo V.",
  "Andrade, Ysabella Faye B.",
  "Babasa, Ghislaine Br.",
  "Barameda, Summer VSN.",
  "Biag, Nigel Shane C.",
  "Codia, Bielle Jonahs A.",
  "Colecha, Kim N.",
  "Dacillo, Luvly Jhamella C.",
  "Dacuya, Althea Joy F.",
  "De la Fuente, Samiel Yara R.",
  "De Luna, Viktoria R.",
  "Gumba, Malaika Ysabella C.",
  "Lista, Matilda Beatriz D.",
  "Llames, Cianna Margarette T.",
  "Lumawon, Xyriel",
  "Mar, Janna Charlie O.",
  "Mengorio, Jelien Purz",
  "Moises, Jinky Faye A.",
  "Morta, Amaia B.",
  "Opiana, Chriatia Fatima M.",
  "Quiapon, Princess Corrine Y.",
  "Ramos, Jaira Nicole S.",
  "Robrigado, Xiarah Nicolette O.",
  "Rojero, Samara Kate D.",
  "Saclag, Precious Jade R.",
  "Satuito, Jaira Airies C.",
  "Soriano, Jaye Anne Nazareth R.",
  "Teodoro, Ella Jezrell E.",
  "Viray, Dennise Keith Y.",
  "Yap, Chahna Mishael F.",
];

export function rosterStudents(overrides: Record<string, number>): Student[] {
  return CLASS_NAMES.map((name) => {
    const key = norm(name);
    const hasOverride = Object.prototype.hasOwnProperty.call(overrides, key);
    const points = hasOverride ? overrides[key] : 0;
    return {
      name,
      lastName: lastNameOf(name),
      givenName: givenNameOf(name),
      points,
      sheetPoints: 0,
      eyesight: isKnownEyesight(name),
      key,
      hasOverride,
    };
  });
}

function compareStudents(a: Student, b: Student): number {
  if (a.points !== b.points) return a.points - b.points;
  const byLast = sortLastName(a.lastName).localeCompare(sortLastName(b.lastName), "en", {
    sensitivity: "base",
  });
  if (byLast !== 0) return byLast;
  return a.name.localeCompare(b.name, "en", { sensitivity: "base" });
}

export function arrange(students: Student[]): Plan {
  const chahna = students.find((s) => isChahna(s.name));
  const others = students.filter((s) => !isChahna(s.name));
  const eyesightSorted = others.filter((s) => s.eyesight).slice().sort(compareStudents);
  const frontOthers = eyesightSorted.slice(0, 5);
  const overflow = eyesightSorted.slice(5);
  const front: Student[] = [];
  if (chahna) {
    chahna.eyesight = true;
    front.push(chahna);
  }
  front.push(...frontOthers);
  while (front.length < 6 && overflow.length) {
    const next = overflow.shift();
    if (next) front.push(next);
  }
  const placed = new Set(front);
  const regular = others.filter((s) => !placed.has(s)).slice().sort(compareStudents);

  const byKey = new Map<string, Desk>();
  ROWS.forEach((row, rowFromFront) => {
    const eyes = new Set(row.eyesight);
    row.cols.forEach((col) => {
      byKey.set(rowFromFront + ":" + col, {
        rowFromFront,
        col,
        role: eyes.has(col) ? "eyesight" : "regular",
        student: null,
      });
    });
  });

  front.forEach((student, index) => {
    if (index > 5) return;
    const desk = byKey.get("0:" + index);
    if (desk) desk.student = student;
  });

  const path: Array<{ rowFromFront: number; col: number }> = [];
  ROWS.forEach((row, rowFromFront) => {
    const eyes = new Set(row.eyesight);
    const cols = rowFromFront % 2 === 0 ? row.cols : row.cols.slice().reverse();
    cols.forEach((col) => {
      if (!eyes.has(col)) path.push({ rowFromFront, col });
    });
  });

  const unseated: Student[] = [];
  regular.forEach((student, index) => {
    const slot = path[index];
    if (!slot) {
      unseated.push(student);
      return;
    }
    const desk = byKey.get(slot.rowFromFront + ":" + slot.col);
    if (desk) desk.student = student;
  });

  return { desks: [...byKey.values()], unseated, studentCount: students.length };
}

type GvizCell = { v?: unknown };
type GvizRow = { c?: Array<GvizCell | null> };
type GvizTable = { cols?: Array<{ label?: string }>; rows?: GvizRow[] };

function cell(row: GvizRow, index: number): unknown {
  const item = row.c?.[index];
  if (!item || item.v == null) return "";
  return item.v;
}

function parsePoints(raw: unknown): number {
  const cleaned = String(raw ?? "").trim().replace(/,/g, "");
  if (!cleaned) return 0;
  const value = Number(cleaned);
  return Number.isFinite(value) ? Math.max(0, Math.round(value)) : 0;
}

function marked(raw: unknown): boolean {
  const value = String(raw ?? "").trim().toLowerCase();
  if (!value) return false;
  return !["no", "n", "false", "0", "none", "-"].includes(value);
}

export function studentsFromTable(
  table: GvizTable,
  overrides: Record<string, number>,
): Student[] {
  const labels = (table.cols || []).map((col) => norm(col.label || ""));
  const findCol = (aliases: string[]) =>
    labels.findIndex((label) => aliases.some((alias) => label === alias || label.includes(alias)));
  let nameIdx = findCol(["name", "student"]);
  let pointsIdx = findCol(["recitation", "point", "score", "number", "count"]);
  const eyesightIdx = findCol(["eyesight", "eye sight", "vision"]);
  if (nameIdx < 0) nameIdx = 0;
  if (pointsIdx < 0) pointsIdx = 1;
  const rows = table.rows || [];
  const anyMarked = eyesightIdx >= 0 && rows.some((row) => marked(cell(row, eyesightIdx)));
  const students: Student[] = [];
  rows.forEach((row) => {
    const name = String(cell(row, nameIdx) || "").trim().replace(/\s+/g, " ");
    if (!name || /^name$/i.test(name)) return;
    const key = norm(name);
    const sheetPoints = parsePoints(cell(row, pointsIdx));
    const hasOverride = Object.prototype.hasOwnProperty.call(overrides, key);
    const points = hasOverride ? overrides[key] : sheetPoints;
    const eyesight = anyMarked ? marked(cell(row, eyesightIdx)) : isKnownEyesight(name);
    students.push({
      name,
      lastName: lastNameOf(name),
      givenName: givenNameOf(name),
      points,
      sheetPoints,
      eyesight,
      key,
      hasOverride,
    });
  });
  return students;
}

export async function sha256Hex(ascii: string): Promise<string> {
  const data = new TextEncoder().encode(ascii);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

declare global {
  interface Window {
    [key: string]: unknown;
  }
}

export function loadSheetTable(): Promise<{ table: GvizTable; sig: string }> {
  return new Promise((resolve, reject) => {
    const cb = "seatPlanCb" + Date.now();
    const script = document.createElement("script");
    let settled = false;
    const timer = window.setTimeout(() => finish(new Error("The recitation sheet didn't respond.")), 12000);
    function finish(error: Error | null, table?: GvizTable, sig?: string) {
      if (settled) return;
      settled = true;
      window.clearTimeout(timer);
      try {
        delete window[cb];
      } catch {
        window[cb] = undefined;
      }
      script.remove();
      if (error || !table) reject(error || new Error("Empty sheet"));
      else resolve({ table, sig: sig || "" });
    }
    window[cb] = (payload: { status?: string; table?: GvizTable; sig?: string }) => {
      if (!payload || payload.status !== "ok" || !payload.table) {
        finish(
          new Error(
            "The sheet isn't public. In Google Sheets, set sharing to anyone with the link can view.",
          ),
        );
        return;
      }
      finish(null, payload.table, payload.sig || "");
    };
    script.onerror = () => finish(new Error("Couldn't reach the recitation sheet."));
    script.src =
      "https://docs.google.com/spreadsheets/d/" +
      SHEET_ID +
      "/gviz/tq?tqx=" +
      encodeURIComponent("out:json;responseHandler:" + cb) +
      "&gid=0&headers=1&_=" +
      Date.now();
    document.head.appendChild(script);
  });
}
