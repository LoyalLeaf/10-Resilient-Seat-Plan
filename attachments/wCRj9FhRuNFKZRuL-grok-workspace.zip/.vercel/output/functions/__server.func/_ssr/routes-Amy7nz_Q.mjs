import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Eye, n as RefreshCw, r as Pencil } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Amy7nz_Q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EYESIGHT = [
	["berdin", "mathew"],
	["soriano", "jaye"],
	["gumba", "malaika"],
	["llames", "cianna"],
	["de luna", "viktoria"],
	["yap", "chahna"]
];
var ROWS = [
	{
		cols: [
			0,
			1,
			2,
			3,
			4,
			5,
			6,
			7
		],
		eyesight: [
			0,
			1,
			2,
			3,
			4,
			5
		]
	},
	{
		cols: [
			0,
			1,
			2,
			3,
			4,
			5,
			6,
			7
		],
		eyesight: []
	},
	{
		cols: [
			0,
			1,
			2,
			3,
			4,
			5,
			6,
			7
		],
		eyesight: []
	},
	{
		cols: [
			0,
			1,
			2,
			3,
			4,
			5,
			6,
			7
		],
		eyesight: []
	},
	{
		cols: [
			2,
			3,
			4,
			5,
			6
		],
		eyesight: []
	}
];
/** Last 4 digits of each LRN. Key is a normalized "Last, Given" name. */
var LRN_LAST4 = {
	"arickx christoff r": "0003",
	"berdin mathew s": "0062",
	"datoon joshua caleb d": "0009",
	"olivan rein christian s": "0027",
	"ortile jun christian o": "0012",
	"patetico jesutivo noah": "9147",
	"prellegera john stephen p": "0054",
	"tominio carlo v": "0039",
	"andrade ysabella faye b": "0012",
	"babasa ghislaine br": "0022",
	"barameda summer vsn": "0039",
	"biag nigel shane c": "0072",
	"codia bielle jonahs a": "0191",
	"colecha kim n": "0079",
	"dacillo luvly jhamella c": "0010",
	"dacuya althea joy f": "0037",
	"de la fuente samiel yara r": "0138",
	"de luna viktoria r": "0009",
	"gumba malaika ysabella c": "0155",
	"lista matilda beatriz d": "0026",
	"llames cianna margarette t": "0039",
	"lumawon xyriel": "0108",
	"mar janna charlie o": "0025",
	"mengorio jelien purz": "0033",
	"moises jinky faye a": "0130",
	"morta amaia b": "0043",
	"opiana chriatia fatima m": "0007",
	"quiapon princess corrine y": "0015",
	"ramos jaira nicole s": "0045",
	"robrigado xiarah nicolette o": "0250",
	"rojero samara kate d": "0052",
	"saclag precious jade r": "0054",
	"satuito jaira airies c": "0047",
	"soriano jaye anne nazareth r": "0012",
	"teodoro ella jezrell e": "0029",
	"viray dennise keith y": "0157",
	"yap chahna mishael f": "0141"
};
var SHEET_ID = "1Tok7fSsvIQWPN0cSUatx0NEQAPfbxbOR1clv8S1q6l8";
var SHEET_EDIT_URL = "https://docs.google.com/spreadsheets/d/" + SHEET_ID + "/edit?gid=0#gid=0";
var BANDS = [
	{
		id: "rose",
		label: "Under 10"
	},
	{
		id: "sand",
		label: "10+"
	},
	{
		id: "mint",
		label: "15+"
	},
	{
		id: "ice",
		label: "20+"
	},
	{
		id: "deep",
		label: "25+"
	},
	{
		id: "lilac",
		label: "30+"
	},
	{
		id: "amber",
		label: "35+"
	},
	{
		id: "teal",
		label: "40+"
	},
	{
		id: "indigo",
		label: "45+"
	},
	{
		id: "gold",
		label: "50"
	}
];
function norm(value) {
	return String(value || "").toLowerCase().replace(/\./g, "").replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}
function lastNameOf(full) {
	const i = full.indexOf(",");
	return (i === -1 ? full : full.slice(0, i)).trim();
}
function givenNameOf(full) {
	const i = full.indexOf(",");
	return (i === -1 ? "" : full.slice(i + 1)).trim();
}
function sortLastName(last) {
	const particles = /* @__PURE__ */ new Set([
		"de",
		"del",
		"dela",
		"la",
		"los",
		"las",
		"san",
		"santa",
		"sta",
		"sto"
	]);
	const parts = last.split(/\s+/).filter(Boolean);
	let index = 0;
	while (index < parts.length - 1 && particles.has(parts[index].toLowerCase().replace(/\./g, ""))) index += 1;
	return index > 0 ? parts.slice(index).join(" ") : last;
}
function isKnownEyesight(name) {
	const last = norm(lastNameOf(name));
	const given = norm(givenNameOf(name));
	return EYESIGHT.some(([l, g]) => last === l && given.startsWith(g));
}
function isChahna(name) {
	return norm(name) === "yap chahna mishael f" || norm(lastNameOf(name)) === "yap" && norm(givenNameOf(name)).startsWith("chahna");
}
function bandFor(points) {
	if (points < 10) return "rose";
	if (points < 15) return "sand";
	if (points < 20) return "mint";
	if (points < 25) return "ice";
	if (points < 30) return "deep";
	if (points < 35) return "lilac";
	if (points < 40) return "amber";
	if (points < 45) return "teal";
	if (points < 50) return "indigo";
	return "gold";
}
function compareStudents(a, b) {
	if (a.points !== b.points) return a.points - b.points;
	const byLast = sortLastName(a.lastName).localeCompare(sortLastName(b.lastName), "en", { sensitivity: "base" });
	if (byLast !== 0) return byLast;
	return a.name.localeCompare(b.name, "en", { sensitivity: "base" });
}
function arrange(students) {
	const chahna = students.find((s) => isChahna(s.name));
	const others = students.filter((s) => !isChahna(s.name));
	const eyesightSorted = others.filter((s) => s.eyesight).slice().sort(compareStudents);
	const frontOthers = eyesightSorted.slice(0, 5);
	const overflow = eyesightSorted.slice(5);
	const front = [];
	if (chahna) {
		chahna.eyesight = true;
		front.push(chahna);
	}
	front.push(...frontOthers);
	while (front.length < 6 && overflow.length) {
		const next = overflow.shift();
		if (next) front.push(next);
	}
	const placed = new Set(front);
	const regular = others.filter((s) => !placed.has(s)).slice().sort(compareStudents);
	const byKey = /* @__PURE__ */ new Map();
	ROWS.forEach((row, rowFromFront) => {
		const eyes = new Set(row.eyesight);
		row.cols.forEach((col) => {
			byKey.set(rowFromFront + ":" + col, {
				rowFromFront,
				col,
				role: eyes.has(col) ? "eyesight" : "regular",
				student: null
			});
		});
	});
	front.forEach((student, index) => {
		if (index > 5) return;
		const desk = byKey.get("0:" + index);
		if (desk) desk.student = student;
	});
	const path = [];
	ROWS.forEach((row, rowFromFront) => {
		const eyes = new Set(row.eyesight);
		(rowFromFront % 2 === 0 ? row.cols : row.cols.slice().reverse()).forEach((col) => {
			if (!eyes.has(col)) path.push({
				rowFromFront,
				col
			});
		});
	});
	const unseated = [];
	regular.forEach((student, index) => {
		const slot = path[index];
		if (!slot) {
			unseated.push(student);
			return;
		}
		const desk = byKey.get(slot.rowFromFront + ":" + slot.col);
		if (desk) desk.student = student;
	});
	return {
		desks: [...byKey.values()],
		unseated,
		studentCount: students.length
	};
}
function cell(row, index) {
	const item = row.c?.[index];
	if (!item || item.v == null) return "";
	return item.v;
}
function parsePoints(raw) {
	const cleaned = String(raw ?? "").trim().replace(/,/g, "");
	if (!cleaned) return 0;
	const value = Number(cleaned);
	return Number.isFinite(value) ? Math.max(0, Math.round(value)) : 0;
}
function marked(raw) {
	const value = String(raw ?? "").trim().toLowerCase();
	if (!value) return false;
	return ![
		"no",
		"n",
		"false",
		"0",
		"none",
		"-"
	].includes(value);
}
function studentsFromTable(table, overrides) {
	const labels = (table.cols || []).map((col) => norm(col.label || ""));
	const findCol = (aliases) => labels.findIndex((label) => aliases.some((alias) => label === alias || label.includes(alias)));
	let nameIdx = findCol(["name", "student"]);
	let pointsIdx = findCol([
		"recitation",
		"point",
		"score",
		"number",
		"count"
	]);
	const eyesightIdx = findCol([
		"eyesight",
		"eye sight",
		"vision"
	]);
	if (nameIdx < 0) nameIdx = 0;
	if (pointsIdx < 0) pointsIdx = 1;
	const rows = table.rows || [];
	const anyMarked = eyesightIdx >= 0 && rows.some((row) => marked(cell(row, eyesightIdx)));
	const students = [];
	rows.forEach((row) => {
		const name = String(cell(row, nameIdx) || "").trim().replace(/\s+/g, " ");
		if (!name || /^name$/i.test(name)) return;
		const key = norm(name);
		const sheetPoints = parsePoints(cell(row, pointsIdx));
		const hasOverride = Object.prototype.hasOwnProperty.call(overrides, key);
		const points = hasOverride ? overrides[key] : sheetPoints;
		const eyesight = anyMarked ? marked(cell(row, eyesightIdx)) : isKnownEyesight(name);
		students.push({
			name,
			lastName: lastNameOf(name),
			givenName: givenNameOf(name),
			points,
			sheetPoints,
			eyesight,
			key,
			hasOverride
		});
	});
	return students;
}
async function sha256Hex(ascii) {
	const data = new TextEncoder().encode(ascii);
	const buf = await crypto.subtle.digest("SHA-256", data);
	return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function loadSheetTable() {
	return new Promise((resolve, reject) => {
		const cb = "seatPlanCb" + Date.now();
		const script = document.createElement("script");
		let settled = false;
		const timer = window.setTimeout(() => finish(/* @__PURE__ */ new Error("The recitation sheet didn't respond.")), 12e3);
		function finish(error, table, sig) {
			if (settled) return;
			settled = true;
			window.clearTimeout(timer);
			try {
				delete window[cb];
			} catch {
				window[cb] = void 0;
			}
			script.remove();
			if (error || !table) reject(error || /* @__PURE__ */ new Error("Empty sheet"));
			else resolve({
				table,
				sig: sig || ""
			});
		}
		window[cb] = (payload) => {
			if (!payload || payload.status !== "ok" || !payload.table) {
				finish(/* @__PURE__ */ new Error("The sheet isn't public. In Google Sheets, set sharing to anyone with the link can view."));
				return;
			}
			finish(null, payload.table, payload.sig || "");
		};
		script.onerror = () => finish(/* @__PURE__ */ new Error("Couldn't reach the recitation sheet."));
		script.src = "https://docs.google.com/spreadsheets/d/" + SHEET_ID + "/gviz/tq?tqx=" + encodeURIComponent("out:json;responseHandler:" + cb) + "&gid=0&headers=1&_=" + Date.now();
		document.head.appendChild(script);
	});
}
var UNLOCK_KEY = "seat-plan-unlock";
var OVERRIDES_KEY = "seat-plan-overrides";
function Home() {
	const [plan, setPlan] = (0, import_react.useState)(null);
	const [students, setStudents] = (0, import_react.useState)([]);
	const [sig, setSig] = (0, import_react.useState)("");
	const [fetchedAt, setFetchedAt] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [query, setQuery] = (0, import_react.useState)("");
	const [unlocked, setUnlocked] = (0, import_react.useState)(false);
	const [showNumbers, setShowNumbers] = (0, import_react.useState)(false);
	const [overrides, setOverrides] = (0, import_react.useState)({});
	const [gate, setGate] = (0, import_react.useState)(null);
	const [password, setPassword] = (0, import_react.useState)("");
	const [gateError, setGateError] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [lrn, setLrn] = (0, import_react.useState)("");
	const [nextPoints, setNextPoints] = (0, import_react.useState)("");
	const [editError, setEditError] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			if (sessionStorage.getItem(UNLOCK_KEY) === "1") setUnlocked(true);
			const raw = localStorage.getItem(OVERRIDES_KEY);
			if (raw) {
				const parsed = JSON.parse(raw);
				if (parsed && typeof parsed === "object") setOverrides(parsed);
			}
		} catch {}
	}, []);
	const overridesRef = (0, import_react.useRef)(overrides);
	const sigRef = (0, import_react.useRef)(sig);
	overridesRef.current = overrides;
	sigRef.current = sig;
	const refresh = (0, import_react.useCallback)(async (force = false) => {
		setLoading(true);
		try {
			const result = await loadSheetTable();
			setError("");
			setFetchedAt((/* @__PURE__ */ new Date()).toISOString());
			if (!force && result.sig && result.sig === sigRef.current) {
				setLoading(false);
				return;
			}
			setSig(result.sig);
			const next = studentsFromTable(result.table, overridesRef.current);
			setStudents(next);
			setPlan(arrange(next));
		} catch (err) {
			setError(err instanceof Error ? err.message : "Couldn't reach the sheet.");
		} finally {
			setLoading(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		refresh(true);
		const id = window.setInterval(() => void refresh(false), 2e4);
		const onVis = () => {
			if (document.visibilityState === "visible") refresh(false);
		};
		document.addEventListener("visibilitychange", onVis);
		return () => {
			window.clearInterval(id);
			document.removeEventListener("visibilitychange", onVis);
		};
	}, [refresh]);
	(0, import_react.useEffect)(() => {
		if (!students.length) return;
		const next = students.map((student) => {
			const hasOverride = Object.prototype.hasOwnProperty.call(overrides, student.key);
			return {
				...student,
				hasOverride,
				points: hasOverride ? overrides[student.key] : student.sheetPoints
			};
		});
		setStudents(next);
		setPlan(arrange(next));
	}, [overrides]);
	const byKey = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		plan?.desks.forEach((desk) => map.set(desk.rowFromFront + ":" + desk.col, desk));
		return map;
	}, [plan]);
	const needle = norm(query);
	const hits = needle ? plan?.desks.filter((d) => d.student && norm(d.student.name).includes(needle)).length ?? 0 : 0;
	function rememberUnlock() {
		setUnlocked(true);
		try {
			sessionStorage.setItem(UNLOCK_KEY, "1");
		} catch {}
	}
	async function submitGate(event) {
		event.preventDefault();
		if (await sha256Hex(password) !== "eafa8d7ce4f9a2fd94e491b48c7f83ad180466680cd0d44d016b9192ff4a5143") {
			setGateError(true);
			return;
		}
		rememberUnlock();
		const intent = gate;
		setGate(null);
		setPassword("");
		setGateError(false);
		if (intent === "numbers") setShowNumbers(true);
		if (intent === "sheet") window.open(SHEET_EDIT_URL, "_blank", "noopener");
	}
	function submitEdit(event) {
		event.preventDefault();
		if (!editing) return;
		const expected = LRN_LAST4[editing.key];
		if (!expected || lrn.trim() !== expected) {
			setEditError(true);
			return;
		}
		const value = Math.max(0, Math.round(Number(nextPoints) || 0));
		const next = {
			...overrides,
			[editing.key]: value
		};
		setOverrides(next);
		try {
			localStorage.setItem(OVERRIDES_KEY, JSON.stringify(next));
		} catch {}
		setEditing(null);
		setLrn("");
		setEditError(false);
	}
	const when = fetchedAt ? new Intl.DateTimeFormat("en-PH", {
		timeZone: "Asia/Manila",
		month: "short",
		day: "numeric",
		hour: "numeric",
		minute: "2-digit"
	}).format(new Date(fetchedAt)) : "";
	const overrideCount = Object.keys(overrides).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-7xl px-4 py-6 pb-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-6 flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "m-0 text-xs font-bold tracking-widest text-muted uppercase",
						children: "Live from the class sheet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-4xl font-medium tracking-tight",
						children: "Seat plan"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: !plan ? "Waiting on the recitation sheet" : `${plan.studentCount} students · synced ${when}${loading ? " · checking" : ""} · ${showNumbers ? "numbers on" : "numbers hidden"}${overrideCount ? ` · ${overrideCount} local edit${overrideCount === 1 ? "" : "s"}` : ""}`
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "h-11 w-56 max-w-full rounded-lg border border-line bg-paper px-3 text-sm font-semibold text-ink",
							type: "search",
							placeholder: "Find a student",
							"aria-label": "Find a student",
							value: query,
							onChange: (event) => setQuery(event.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex h-11 items-center gap-2 rounded-lg border border-line px-4 text-sm font-semibold",
							onClick: () => void refresh(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
								className: "size-4",
								"aria-hidden": true
							}), "Refresh"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex h-11 items-center rounded-lg border border-line px-4 text-sm font-semibold",
							onClick: () => {
								if (showNumbers) {
									setShowNumbers(false);
									return;
								}
								if (unlocked) {
									setShowNumbers(true);
									return;
								}
								setGate("numbers");
								setPassword("");
								setGateError(false);
							},
							children: showNumbers ? "Hide numbers" : "Show numbers"
						}),
						unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex h-11 items-center rounded-lg border border-line px-4 text-sm font-semibold",
							onClick: () => {
								setUnlocked(false);
								setShowNumbers(false);
								try {
									sessionStorage.removeItem(UNLOCK_KEY);
								} catch {}
							},
							children: "Lock"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex h-11 items-center rounded-lg bg-ink px-4 text-sm font-semibold text-paper",
							onClick: () => {
								if (unlocked) {
									window.open(SHEET_EDIT_URL, "_blank", "noopener");
									return;
								}
								setGate("sheet");
								setPassword("");
								setGateError(false);
							},
							children: "Open sheet"
						})
					]
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 rounded-lg bg-rose px-4 py-3 text-sm text-rose-fg",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-center text-xs font-bold tracking-widest text-muted uppercase",
				children: "Back of the room"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs text-muted lg:hidden",
				children: "Swipe sideways to see every column."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto pb-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `room ${needle ? "[&_.desk:not(.desk-hit)]:opacity-35" : ""}`,
					children: [
						4,
						3,
						2,
						1,
						0
					].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						row,
						byKey,
						needle,
						showNumbers,
						onEdit: openEdit
					}, row))
				})
			}),
			needle && hits === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No one by that name on the plan."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto mt-4 max-w-md rounded-lg bg-ink px-6 py-4 text-center font-display text-xl text-paper",
				children: "Teacher’s Table"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-center text-xs font-bold tracking-widest text-muted uppercase",
				children: "Front of the room"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-6 flex list-none flex-wrap gap-x-4 gap-y-2 p-0 text-sm",
				children: [BANDS.map((band) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `desk-${band.id} size-4 rounded-full border border-ink/20` }), band.label]
				}, band.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-4 rounded-full border-2 border-dashed border-ink bg-paper" }), "Eyesight seat"]
				})]
			}),
			plan && plan.unseated.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-bold",
					children: "No desk left"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 flex list-none flex-wrap gap-2 p-0",
					children: plan.unseated.map((student) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-full border border-line bg-paper px-3 py-1 text-sm",
						children: [student.name, showNumbers ? ` · ${student.points}` : ""]
					}, student.key))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "mt-6 max-w-2xl border-t border-line pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "cursor-pointer font-bold",
					children: "How seats are chosen"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-2 space-y-2 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Chahna Yap stays at the front-left eyesight seat. The other five eyesight seats rank left to right, fewest recitations first." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Everyone else zigzags from the front-left regular seats: left to right, then right to left, toward the back. Fewest first. Same score sorts by last name, skipping a leading de or de la." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Exact counts stay hidden until the class password. The plan rechecks the spreadsheet on its own." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The pencil asks for the last four digits of that student’s LRN, then updates seating in this browser. The Google Sheet itself is not written from this page." })
					]
				})]
			}),
			gate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 flex items-center justify-center bg-ink/40 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "w-full max-w-sm rounded-2xl border-2 border-ink bg-paper p-6",
					onSubmit: (event) => void submitGate(event),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold tracking-widest text-muted uppercase",
							children: "Class password"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-xl",
							children: gate === "sheet" ? "Open the sheet" : "Show recitation numbers"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: gate === "sheet" ? "The spreadsheet stays locked until the class password is entered." : "Names and colors stay visible. The exact counts need the class password."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-4 block text-sm font-bold",
							htmlFor: "class-password",
							children: "Password"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "class-password",
							className: "mt-2 h-11 w-full rounded-lg border border-line bg-paper px-3",
							type: "password",
							autoComplete: "current-password",
							value: password,
							onChange: (event) => {
								setPassword(event.target.value);
								setGateError(false);
							},
							autoFocus: true
						}),
						gateError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-rose-fg",
							children: "That password isn’t right."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-11 rounded-lg border border-line px-4 text-sm font-semibold",
								onClick: () => setGate(null),
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "h-11 rounded-lg bg-ink px-4 text-sm font-semibold text-paper",
								children: "Unlock"
							})]
						})
					]
				})
			}) : null,
			editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 flex items-center justify-center bg-ink/40 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "w-full max-w-sm rounded-2xl border-2 border-ink bg-paper p-6",
					onSubmit: submitEdit,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold tracking-widest text-muted uppercase",
							children: "Student edit"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-xl",
							children: editing.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Enter the last four digits of this student’s LRN, then the new count. Seating updates at once. Edits stay in this browser only."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-4 block text-sm font-bold",
							htmlFor: "edit-lrn",
							children: "Last 4 of LRN"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "edit-lrn",
							className: "mt-2 h-11 w-full rounded-lg border border-line bg-paper px-3",
							type: "password",
							inputMode: "numeric",
							maxLength: 4,
							autoComplete: "off",
							value: lrn,
							onChange: (event) => {
								setLrn(event.target.value);
								setEditError(false);
							},
							autoFocus: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-4 block text-sm font-bold",
							htmlFor: "edit-points",
							children: "New recitation count"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "edit-points",
							className: "mt-2 h-11 w-full rounded-lg border border-line bg-paper px-3",
							type: "number",
							min: 0,
							step: 1,
							value: nextPoints,
							onChange: (event) => setNextPoints(event.target.value)
						}),
						editError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-rose-fg",
							children: "That LRN does not match this student."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-11 rounded-lg border border-line px-4 text-sm font-semibold",
								onClick: () => setEditing(null),
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "h-11 rounded-lg bg-ink px-4 text-sm font-semibold text-paper",
								children: "Save"
							})]
						})
					]
				})
			}) : null
		]
	});
	function openEdit(student) {
		setEditing(student);
		setLrn("");
		setNextPoints(String(student.points));
		setEditError(false);
	}
}
function Row({ row, byKey, needle, showNumbers, onEdit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		[
			0,
			1,
			2,
			3
		].map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskCard, {
			desk: byKey.get(row + ":" + col),
			needle,
			showNumbers,
			onEdit
		}, col)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { "aria-hidden": true }),
		[
			4,
			5,
			6,
			7
		].map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskCard, {
			desk: byKey.get(row + ":" + col),
			needle,
			showNumbers,
			onEdit
		}, col))
	] });
}
function DeskCard({ desk, needle, showNumbers, onEdit }) {
	if (!desk) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { "aria-hidden": true });
	const student = desk.student;
	if (!student) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "desk desk-empty",
		"aria-label": "Empty desk"
	});
	const hit = Boolean(needle && norm(student.name).includes(needle));
	const eyesight = student.eyesight || desk.role === "eyesight";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: `desk desk-${bandFor(student.points)} ${eyesight ? "desk-eyesight" : ""} ${hit ? "desk-hit" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "m-0 text-xs font-bold uppercase leading-tight break-words",
				children: student.lastName
			}),
			student.givenName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs leading-tight break-words",
				children: student.givenName
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-auto flex items-center justify-between gap-1 pt-2",
				children: [
					eyesight ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {
						className: "size-3.5",
						"aria-label": "Eyesight seat"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
					showNumbers ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-auto text-sm font-bold tabular-nums",
						children: [student.points, student.hasOverride ? "*" : ""]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex size-7 items-center justify-center rounded text-current opacity-60 hover:opacity-100",
						"aria-label": `Edit recitations for ${student.name}`,
						title: "Edit recitations",
						onClick: () => onEdit(student),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3" })
					})
				]
			})
		]
	});
}
//#endregion
export { Home as component };
